
//SOLID Principle Example
import Foundation


//single Responsiblity

//class Handler{
//    func handle(){
//
//    }
//
//    private func requestDataToAPI()-> Data{
//       //Send API request wait for the response
//        return Data()
//    }
//
//
//    private func praseData(data:Data) ->[String]{
//        return []
//    }
//
//    private func saveToDB(array:[String]){
//
//    }
//
//}

//This is not a SOLID princples classes having more than one responsibility


//class Handler
//{
//    let apiHandeler : APIHandler
//    let parseHandler : ParseHandler
//    let dbHandler :DBHandler
//
//    init(apiHandler:APIHandler,parseHandler:ParseHandler,dbHandler:DBHandler) {
//        self.apiHandeler = apiHandler
//        self.parseHandler = parseHandler
//        self.dbHandler = dbHandler
//    }
//
//    func handle(){
//        let data = apiHandeler.requestDataToAPI()
//        let array = parseHandler.parse(data: data)
//        dbHandler.saveToDB(array: array)
//    }
//
//}
//
//class APIHandler
//{
//    func requestDataToAPI()->Data{
//        //Request data
//        return Data()
//    }
//}
//
//class ParseHandler
//{
//    func parse(data:Data)->[String]{
//        //Parse data coming from API
//        return []
//    }
//
//}
//
//class DBHandler
//{
//    func saveToDB(array:[String]){
//        //Save to DB
//    }
//}
// Best way to implement single responsibilty role.....



//Open /closed Principle open for extensions closed for modifications

//class Circle {
//    var radius : Double
//
//    init(radius:Double) {
//        self.radius = radius
//    }
//
//}
//
//class Rectangle
//{
//    var width :Double
//    var height : Double
//    init(width:Double, height:Double) {
//        self.width = width
//        self.height = height
//    }
//
//}
//
//
//class AreaCalculator
//{
//    func area(shape:AnyObject)->Double{
//        var area : Double = 0.0
//
//        if (shape is Rectangle) {
//            let rectangle = shape as! Rectangle
//            area = rectangle.width * rectangle.height
//        }
//        else if (shape is Circle)
//        {
//            let circle = shape as! Circle
//             area = circle.radius * circle.radius
//        }
//
//        return area
//
//    }
//}


//Wrong way of implemendting open / Closed principle because adding new feature required modifications in current logic

// Right way of using it by using Protocal

//Protocal Oriented Programming and way to achieving the multiple inheritance

//protocol Shape {
//    func area()->Double
//}
//
//class Circle: Shape{
//   var radius:Double = 8.0
//    func area() -> Double {
//        return radius*radius
//    }
//
//}
//
//class Rectangle:Shape{
//  var width:Double = 12.0
//    var height:Double = 7.5
//    func area() -> Double {
//        return width*height
//    }
//}
//
//class CalculateArea
//{
//     func area(shape:Shape)->Double
//    {
//       return shape.area()
//    }
//
//}
//
//let objArea = CalculateArea()
//objArea.area(shape: Rectangle())
//objArea.area(shape: Circle())
